/// <reference path="mobile.ts"/>
namespace nm
{

export class BasicPhone extends mobile

{
    mobileType:string;
    
    constructor(mobileNumber,mobileId, mobileCost,mobileType)
    {
        super(mobileNumber,mobileId, mobileCost);
      
        this.mobileType="Basic Mobile";
    }
     printMobileDes():void
    {
     console.log(this.mobileType);
 }
}
}