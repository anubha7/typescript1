
namespace nm
{
    export class mobile 
{
    mobileNumber:Number;
    mobileId:Number;
    mobileCost:Number;

    constructor(mobileNumber:number,mobileId:number, mobileCost:number)
    {
       this.mobileId=mobileId;
       this.mobileCost=mobileCost;
       this.mobileNumber=mobileNumber;
    }
    printMobileDetail():void
    {
        console.log(this.mobileNumber);
         console.log(this.mobileId);
          console.log(this.mobileCost);


    }

}
}