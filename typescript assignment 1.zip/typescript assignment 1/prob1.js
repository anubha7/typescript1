var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var nm;
(function (nm) {
    var mobile = /** @class */ (function () {
        function mobile(mobileNumber, mobileId, mobileCost) {
            this.mobileId = mobileId;
            this.mobileCost = mobileCost;
            this.mobileNumber = mobileNumber;
        }
        mobile.prototype.printMobileDetail = function () {
            console.log(this.mobileNumber);
            console.log(this.mobileId);
            console.log(this.mobileCost);
        };
        return mobile;
    }());
    nm.mobile = mobile;
})(nm || (nm = {}));
/// <reference path="mobile.ts"/>
var nm;
(function (nm) {
    //import { mobile } from "./mobile";
    var SmartPhone = /** @class */ (function (_super) {
        __extends(SmartPhone, _super);
        function SmartPhone(mobileNumber, mobileId, mobileCost, mobileType) {
            var _this = _super.call(this, mobileNumber, mobileId, mobileCost) || this;
            _this.mobileType = "Smart Phones";
            return _this;
        }
        SmartPhone.prototype.printMobileDes = function () {
            console.log(this.mobileType);
        };
        return SmartPhone;
    }(nm.mobile));
    nm.SmartPhone = SmartPhone;
})(nm || (nm = {}));
/// <reference path="mobile.ts"/>
var nm;
(function (nm) {
    //import { mobile } from "./mobile";
    var BasicPhone = /** @class */ (function (_super) {
        __extends(BasicPhone, _super);
        function BasicPhone(mobileNumber, mobileId, mobileCost, mobileType) {
            var _this = _super.call(this, mobileNumber, mobileId, mobileCost) || this;
            _this.mobileType = "Basic Mobile";
            return _this;
        }
        BasicPhone.prototype.printMobileDes = function () {
            console.log(this.mobileType);
        };
        return BasicPhone;
    }(nm.mobile));
    nm.BasicPhone = BasicPhone;
})(nm || (nm = {}));
/// <reference path="mobile.ts"/>
/// <reference path="SmartPhone.ts"/>
/// <reference path="BasicType.ts"/>
var sp = new nm.SmartPhone("99999999", "11", "10000", "Apple");
sp.printMobileDes();
var bp = new nm.BasicPhone("88888888", "12", "10000", "Nokia");
bp.printMobileDes();
