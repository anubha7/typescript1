/// <reference path="mobile.ts"/>
namespace nm
{
    //import { mobile } from "./mobile";
export class SmartPhone extends mobile
{
    mobileType:string;

    constructor(mobileNumber,mobileId, mobileCost,mobileType)
    {
       super(mobileNumber,mobileId, mobileCost);
       
        this.mobileType="Smart Phones";
    }
    printMobileDes():void
    {
      
       
            console.log(this.mobileType);
  }
}
}




