/// <reference path="mobile.ts"/>
/// <reference path="SmartPhone.ts"/>
/// <reference path="BasicType.ts"/>

var sp=new nm.SmartPhone("99999999","11","10000","Apple");
sp.printMobileDes();
var bp=new nm.BasicPhone("88888888","12","10000","Nokia");
bp.printMobileDes();