var nm;
(function (nm) {
    var mobile = /** @class */ (function () {
        function mobile(mobileNumber, mobileId, mobileCost) {
            this.mobileId = mobileId;
            this.mobileCost = mobileCost;
            this.mobileNumber = mobileNumber;
        }
        mobile.prototype.printMobileDetail = function () {
            console.log(this.mobileNumber);
            console.log(this.mobileId);
            console.log(this.mobileCost);
        };
        return mobile;
    }());
    nm.mobile = mobile;
})(nm || (nm = {}));
